import unittest

from MathProtEnergyProcSynDatas.tests.TestGenerateRandomDatasInDiapasons import TestGenerateRandomDatasInDiapasons
from MathProtEnergyProcSynDatas.tests.TestGenerateRandomDatasInDiapasonsFrame import TestGenerateRandomDatasInDiapasonsFrame

# Запустить тестирование
if __name__ == "__main__":
    unittest.main()
