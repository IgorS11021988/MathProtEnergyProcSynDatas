from .DatasSyntetic import *
